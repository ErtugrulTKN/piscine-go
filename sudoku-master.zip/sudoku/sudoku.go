package main

import (
	"fmt"
	"os"
	"strconv"
)

const boyut = 9

func main() {
	// Komut satırı argümanlarını aldık.
	args := os.Args[1:]
	// Argüman sayısı doğru mu kontrol ettik.
	if len(args) != boyut {
		fmt.Println("Error")
		return
	}
	// Sudoku tahtasını oluşturduk ve ve argümanlar ile doldurduk.
	tahta := make([][]int, boyut)
	for i, arg := range args {
		// Her argümanın uzunluğunu kontrol ettik.
		if len(arg) != boyut {
			fmt.Println("Error")
			return
		}
		tahta[i] = make([]int, boyut)
		for j, char := range arg {
			if char == '.' {
				// Boş hücreleri temsil etmek için 0 kullandık.
				tahta[i][j] = 0
			} else {
				val, err := strconv.Atoi(string(char))
				if err != nil || val < 1 || val > 9 {
					fmt.Println("Error")
					return
				}
				tahta[i][j] = val
			}
		}
	}
	// Sudoku çözümünü başlat.
	if sudokuCoz(tahta) {
		// Sonucu yazdır.
		printBoard(tahta)
	} else {
		fmt.Println("Error")
	}
}

// Sudoku çözümü için kullanılan ana fonksiyon.
func sudokuCoz(tahta [][]int) bool {
	// Boş hücreleri bul.
	bos := bosHucreBul(tahta)
	if bos == nil {
		return true // Sudoku çözüldü.
	}
	row, col := bos[0], bos[1]
	// 1'den 9'a kadar olan sayıları dene
	for num := 1; num <= 9; num++ {
		if gecerliHareket(tahta, row, col, num) {
			tahta[row][col] = num
			if sudokuCoz(tahta) {
				return true
			}
			tahta[row][col] = 0
		}
	}
	return false
}

// Boş hücreleri bulan yardımcı fonksiyon.
func bosHucreBul(tahta [][]int) []int {
	for row := 0; row < boyut; row++ {
		for col := 0; col < boyut; col++ {
			if tahta[row][col] == 0 {
				return []int{row, col}
			}
		}
	}
	return nil
}

func gecerliHareket(tahta [][]int, row, col, num int) bool {
	// Aynı satırda, sütunda veya küçük (3x3) kutuda num değeri kullanılıyor mu kontrol ettik.
	return !usedInRow(tahta, row, num) && !usedInColumn(tahta, col, num) && !usedInBox(tahta, row-row%3, col-col%3, num)
}

// Bir rakamın bir satırda kullanılıp kullanılmadığını kontrol eden yardımcı fonksiyon.
func usedInRow(tahta [][]int, row, num int) bool {
	for col := 0; col < boyut; col++ {
		if tahta[row][col] == num {
			return true
		}
	}
	return false
}

// Bir rakamın bir sütunda kullanılıp kullanılmadığını kontrol eden yardımcı fonksiyon.
func usedInColumn(tahta [][]int, col, num int) bool {
	for row := 0; row < boyut; row++ {
		if tahta[row][col] == num {
			return true
		}
	}
	return false
}

// Bir rakamın 3x3 kutu içinde kullanılıp kullanılmadığını kontrol eden yardımcı fonksiyon.
func usedInBox(tahta [][]int, startRow, startCol, num int) bool {
	for row := 0; row < 3; row++ {
		for col := 0; col < 3; col++ {
			if tahta[row+startRow][col+startCol] == num {
				return true
			}
		}
	}
	return false
}

// Tahtayı yazdırmak için kullanılan fonksiyon.
func printBoard(tahta [][]int) {
	for _, row := range tahta {
		for _, num := range row {
			fmt.Printf("%d ", num)
		}
		fmt.Println()
	}
}
